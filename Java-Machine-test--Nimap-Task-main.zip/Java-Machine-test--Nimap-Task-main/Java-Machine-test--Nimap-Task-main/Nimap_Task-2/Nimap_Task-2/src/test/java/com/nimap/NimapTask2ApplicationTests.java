package com.nimap;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class NimapTask2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
